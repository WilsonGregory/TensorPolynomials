# TensorPolynomials
Library to compute general polynomials from tensors to tensors in JAX.
